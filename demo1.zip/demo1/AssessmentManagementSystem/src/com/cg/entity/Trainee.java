package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Trainee_details")
public class Trainee {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int detailsId;
	private String traineeName;
	private String moduleName;
	private int mptMarks;
	private int mttMarks;
	private int assignmentMarks;
	private int totalMarks;

	@Override
	public String toString() {
		return "Trainee [detailsId=" + detailsId + ", traineeName=" + traineeName + ", moduleName=" + moduleName
				+ ", mptMarks=" + mptMarks + ", mttMarks=" + mttMarks + ", assignmentMarks=" + assignmentMarks
				+ ", totalMarks=" + totalMarks + "]";
	}

	public Trainee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getDetailsId() {
		return detailsId;
	}

	public void setDetailsId(int detailsId) {
		this.detailsId = detailsId;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public int getMptMarks() {
		return mptMarks;
	}

	public void setMptMarks(int mptMarks) {
		this.mptMarks = mptMarks;
	}

	public int getMttMarks() {
		return mttMarks;
	}

	public void setMttMarks(int mttMarks) {
		this.mttMarks = mttMarks;
	}

	public int getAssignmentMarks() {
		return assignmentMarks;
	}

	public void setAssignmentMarks(int assignmentMarks) {
		this.assignmentMarks = assignmentMarks;
	}

	public int getTotalMarks() {
		return totalMarks;
	}

	public void setTotalMarks(int totalMarks) {
		this.totalMarks = totalMarks;
	}

}
